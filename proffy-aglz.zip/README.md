# Proffy Agilizei Bootcamp

## Iniciando o projeto

1. Instale as dependências para a web e para o server
  a. acesse o diretório web: `cd web`
  b. instale as dependências: `npm install`
  c. teste o start da aplicação: `npm start`
  d. se ainda estiver no diretório web, volte para o root com `cd ..`
  e. acesse o diretório server: `cd server`
  f. instale as dependências: `npm install`
  g. teste o start da aplicação: `npm start`

*Pronto, agora é só acompanhar a aula* ⚡️
